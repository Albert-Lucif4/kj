#ifdef __cplusplus
extern "C" {
#endif

#ifndef _MAIN_H
#define _MAIN_H
    
#include <riki_msgs/PID.h>
#include <riki_msgs/Imu.h>
#include <riki_msgs/Servo.h>
#include <riki_msgs/Sonar.h>
#include <riki_msgs/DHT22.h>
#include <riki_msgs/Battery.h>
#include <riki_msgs/Velocities.h>
#include <riki_msgs/Bluetooth.h>    
#include <riki_msgs/Blue_connect.h>  
#include <std_srvs/Empty.h>
#include <geometry_msgs/Twist.h>    
#include <geometry_msgs/Vector3.h>  
#include "stm32_h.h"
    
int servoSpeed = 10;
double required_angular_vel_z = 0.0;
double required_linear_vel_x = 0.0;
double required_linear_vel_y = 0.0;
uint32_t previous_command_time = 0;

int Motor::counts_per_rev_ = COUNTS_PER_REV;

int PS2_LX,PS2_LY,PS2_RX,PS2_RY,PS2_KEY; 
int PS2_L2,PS2_R2,PS2_L1,PS2_R1;

bool is_first = true;
bool movingPos1 = true; 
static bool imu_is_initialized = false;

void nh_debug(int blude_status);

#define START_TASK_PRIO		    1           
#define START_STK_SIZE 		    512        
TaskHandle_t StartTask_Handler;            
void RIKI_START_TASK(void *pvParameters);        

#define BATTERY_TASK_PRIO		2           
#define BATTERY_STK_SIZE 		128          	
TaskHandle_t BATTERYTask_Handler;          
void battery_task(void *pvParameters);  

#define IMU_TASK_PRIO		    3          
#define IMU_STK_SIZE 		    128         
TaskHandle_t IMUTask_Handler;               
void imu_task(void *pvParameters);          

#define ULTRASONIC_TASK_PRIO    4       
#define ULTRASONIC_STK_SIZE     128       
TaskHandle_t ULTRASONICTask_Handler;        
void ultrasonic_task(void *pvParameters);     

#define TEM_HUM_TASK_PRIO		5          
#define TEM_HUM_STK_SIZE 		128          
TaskHandle_t TEM_HUMTask_Handler;            
void tem_hum_task(void *pvParameters);       

#define BLUETOOTH_TASK_PRIO		6          
#define BLUETOOTH_STK_SIZE 		128          
TaskHandle_t BLUETOOTH_Task_Handler;            
void bluetooth_task(void *pvParameters); 

#define MOVE_BASE_TASK_PRIO		7         
#define MOVE_BASE_STK_SIZE 		256          
TaskHandle_t MOVE_BASETask_Handler;          
void move_base_task(void *pvParameters);  
 
#define BATTERY_MSG_Q_NUM       1       
QueueHandle_t Battery_Queue;            
#define ULTRASONIC_MSG_Q_NUM    1       
QueueHandle_t Ultrasonic_Queue;       
#define IMU_MSG_Q_NUM           10     
QueueHandle_t Imu_Queue;                        
#define TEM_HUM_MSG_Q_NUM       1
QueueHandle_t Tem_Hum_Queue;          
#define TBLUETOOTH_MSG_Q_NUM    1
QueueHandle_t Bluetooth_Queue;  

struct Ultrasonic_distance{
    float Distance1;
}ultrasonic_send_distance,ultrasonic_receive_distance;

struct Tem_Hum{
    float temperature;
    float humidity;
}Tem_Hum_send_value,Tem_Hum_receive_value;

struct Bluetooth_data{
    int connect_stats;
    int angle_x;
    int angle_y;
}Bluetooth_send_data,Bluetooth_receive_data;



#if SERIAL_DEBUG        
	HardwareSerial serial(SERIAL1);
#endif


PID motor1_pid(-254, 254, K_P, K_I, K_D);
PID motor2_pid(-254, 254, K_P, K_I, K_D);
PID motor3_pid(-254, 254, K_P, K_I, K_D);
PID motor4_pid(-254, 254, K_P, K_I, K_D);
Motor motor1(MOTOR1, 255, 29);
Motor motor2(MOTOR2, 255, 29);
Motor motor3(MOTOR3, 255, 29);
Motor motor4(MOTOR4, 255, 29);
Servo servo(SERVO1);

CServoSpeed servo1(SERVO1);
CServoSpeed servo2(SERVO2);

DHT22 dht22(25,60,0,80,0,100);
Kinematics kinematics(MAX_RPM, WHEEL_DIAMETER, FR_WHEELS_DISTANCE, LR_WHEELS_DISTANCE);
Led led;


void pid_callback( const riki_msgs::PID& pid);                          //PID�ص�����
void command_callback( const geometry_msgs::Twist& cmd_msg);            //cmd_msg�ص�����
void servo_callback(const riki_msgs::Servo& servo);                     //servo�ص�����
void bluetooth_callback(const riki_msgs::Blue_connect& blue_connect);   //blue_connect�ص�����
void ShootCallback(const std_srvs::Empty::Request & req, std_srvs::Empty::Response & res);
 
//�����ڵ�����NodeHandle������
ros::NodeHandle  nh;   

//��Ϣ����
riki_msgs::Imu raw_imu_msg;
riki_msgs::Imu sand_imu_msg;
riki_msgs::Imu receive_imu_msg;
riki_msgs::DHT22 raw_dht22_msg;
riki_msgs::Sonar raw_sonar_msg;
riki_msgs::Velocities raw_vel_msg;
riki_msgs::Battery raw_battery_msg;
riki_msgs::Bluetooth raw_bluetooth_msg;
geometry_msgs::Twist ps2_vel_msg;
geometry_msgs::Twist blue_vel_msg;

//ʵ���������ߣ�����"pid"��������������riki_msgs::PID  ʹ�ûص�����pid_callback
ros::Subscriber<riki_msgs::PID> pid_sub("pid", pid_callback);
ros::Subscriber<riki_msgs::Servo> servo_sub("servo",servo_callback);
ros::Subscriber<riki_msgs::Blue_connect> bluetooth_sub("blue_connect",bluetooth_callback);
ros::Subscriber<geometry_msgs::Twist> cmd_sub("cmd_vel", command_callback);

//ʵ���������ߣ�����"cmd_vel"�� ʹ����Ϣ����Ϊgeometry_msgs::Twist 
ros::Publisher ps2_vel_pub("cmd_vel", &ps2_vel_msg);
ros::Publisher blue_vel_pub("cmd_vel", &blue_vel_msg);
ros::Publisher raw_vel_pub("raw_vel", &raw_vel_msg);
ros::Publisher raw_imu_pub("raw_imu", &raw_imu_msg);
ros::Publisher raw_sonar_pub("sonar", &raw_sonar_msg);
ros::Publisher raw_battery_pub("battery", &raw_battery_msg);
ros::Publisher raw_dht22_pub("temperature_humidity", &raw_dht22_msg);
ros::Publisher raw_bluetooth_pub("bluetooth",&raw_bluetooth_msg);


#endif

#ifdef __cplusplus
}
#endif