#ifndef SERVOSPEED_H
#define SERVOSPEED_H

#include "Servo.h" 
#include "config.h"
class CServoSpeed
{
	  private:
			Servo servo;
			bool isMoving;
			bool positionSet;  
			bool waitingForDelay;
			unsigned long initialMillis;
			u8 currentAngle;
			u8 destinationAngle;
			u8 speed;
    public:
			CServoSpeed(Servo_TypeDef _servo):servo(_servo){
				isMoving = false;
				positionSet = false;
				waitingForDelay = false;
				servo.init();
			}
    
			void write(u8 angle);

			void setSpeed(u8 speed) {this->speed = speed;}

			void update(); //must be called once per loop

			bool moving() {return isMoving;}

};

#endif