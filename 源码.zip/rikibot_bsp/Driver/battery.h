#ifdef __cplusplus
extern "C" {
#endif
    
#ifndef _BATTERY_H_
#define _BATTERY_H_ 
#include "config.h"

extern __IO uint16_t ADC_ConvertedValue[1];	 
void Battery_init(void);


#endif // _BATTERY_H_
#ifdef __cplusplus
}
#endif