#ifdef __cplusplus
extern "C" {
#endif
    
#ifndef __TIME7_H
#define __TIME7_H
#include "sys.h"

extern double ps2_linear_vel_x;
extern double ps2_linear_vel_y;
extern double ps2_angular_vel;
extern int flag;
extern int shoot_flag;
extern uint8_t	beforeKeyStauts;
    
    
    
void TIM7_Int_Init(u16 arr,u16 psc);


extern volatile unsigned long long FreeRTOSRunTimeTicks;
void ConfigureTimeForRunTimeStats(void);
    
#endif

    
    
#ifdef __cplusplus
}
#endif
