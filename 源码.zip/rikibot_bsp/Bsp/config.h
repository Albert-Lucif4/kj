#ifndef _CONFIG_H_
#define _CONFIG_H_

#include <errno.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <math.h>               
#include "stm32f10x.h"          
#include "ring_buffer.h"        
#include "millisecondtimer.h"   

#define PS2_DEBUG_    1
#define PS2_X_VALUE_  128
#define PS2_Y_VALUE_  127

#define PI      3.1415926
#define DEBUG   1

//����ͨ��ģʽѡ��  Ĭ����ROSSERIALģʽ�������Ҫ������ص��ԣ����Կ�����ͨ��Ƭ���������ģʽ  ��ʱ����Windowns�������ֽ�����������Ϣ
#define SERIAL_DEBUG            0      //��ͨ��Ƭ���������ģʽ      
#define ROSSERIAL               1      //ROS rosserialͨ��ģʽ  

//����ѡ�� ����Ĭ���� ��������ת���� ���������û��ɸ���ʵ�ʳ������޸� ������д����
#define  RIKIBOT_2WD            0       //��������ת����
#define  RIKIBOT_4WD            1       //��������ת���ͣ����������ķ�ֳ��ͣ�
#define  RIKIBOT_ACKERMANN      0       //���������ת����
#define  RIKIBOT_OMNI_3WD       0       //OMNI 3�ֲ���ת����
#define  RIKIBOT_TANK           0       //�Ĵ���������ת���ͣ�̹�ˣ�

//���ݻ��ⷢ��Ƶ��
#define IMU_PUBLISH_RATE        100      //hz
#define COMMAND_RATE            100      //hz
#define PS2_COMMAND_RATE        50      //hz
#define BLUETOOTH_PUBLISH_RATE  10      //hz
#define ULT_PUBLISH_RATE        5       //hz
#define DEBUG_RATE              1       //hz
#define BAT_PUBLISH_RATE        0.2     //hz
#define TMP_TUM_PUBLISH_RATE    0.2     //hz

/** ������� **/
#define MAX_RPM         366         //������ת��RPM
#define COUNTS_PER_REV  1560        //����������390 * 4��AB�������½��زɼ���

//��������ת���� ����
#if RIKIBOT_2WD
#define K_P    0.2                  //P constant
#define K_I    0.1                  //I constant
#define K_D    0.1                  //D constant
#define LR_WHEELS_DISTANCE 0.172    //�������  ��λ��
#define FR_WHEELS_DISTANCE 0        //ǰ�����  ��λ��
#define WHEEL_DIAMETER  0.068       //����ֱ��  ��λ��
#endif

//��������ת���ͣ����������ķ�ֺ����֣� ����
#if RIKIBOT_4WD
#define K_P    0.1                  //P constant
#define K_I    0.1                  //I constant
#define K_D    0.08                 //D constant
#define LR_WHEELS_DISTANCE 0.245    //������� ��λ��
#define FR_WHEELS_DISTANCE 0.150    //ǰ����� ��λ��
#define WHEEL_DIAMETER  0.096       //����ֱ�� ��λ��
#endif

//���������ת���� ����
#if RIKIBOT_ACKERMANN
#define K_P    0.09                 //P constant
#define K_I    0.045                //I constant
#define K_D    0.02                 //D constant
#define LR_WHEELS_DISTANCE 0.245    //�������  ��λ��
#define FR_WHEELS_DISTANCE 0.0      //ǰ�����  ��λ��
#define WHEEL_DIAMETER  0.068       //����ֱ��  ��λ��
#define MAX_STEERING_ANGLE		1.8 //���Ƕ�
#define SERVO_POS				90  //������ǰ��ת�����ֵ
#endif

//OMNI 3�ֲ���ת���� ����
#if RIKIBOT_OMNI_3WD
#define K_P    0.09                 //P constant
#define K_I    0.045                //I constant
#define K_D    0.02                 //D constant
#define LR_WHEELS_DISTANCE 0.20     //�������  ��λ��
#define FR_WHEELS_DISTANCE 0.17     //ǰ�����  ��λ��
#define WHEEL_DIAMETER  0.06        //����ֱ��  ��λ��
#endif

//�Ĵ���������ת���ͣ�̹�ˣ�����
#if RIKIBOT_TANK
#define K_P    0.2                  //P constant
#define K_I    0.1                  //I constant
#define K_D    0.1                  //D constant
#define LR_WHEELS_DISTANCE 0.24     //�������  ��λ��
#define FR_WHEELS_DISTANCE 0        //ǰ�����  ��λ��
#define WHEEL_DIAMETER  0.045       //����ֱ��  ��λ��
#endif

#define 	USE_SERIAL1
#define 	USE_SERIAL2
#define 	USE_SERIAL3
#define     USE_MOTOR1
#define     USE_MOTOR2
#define     USE_MOTOR3
#define     USE_MOTOR4
#define     USE_ENCODER1
#define     USE_ENCODER2
#define     USE_ENCODER3
#define     USE_ENCODER4
#define     USE_I2C
#define     USE_SERVO1
#define     USE_SERVO2
#define     USE_SONAR

/** --------Serial Config-------- **/
typedef enum {
	SERIAL1 = 0,
	SERIAL2 = 1,
	SERIAL_END = 2
}Serial_TypeDef; 

#define SERIALn							2

#define RIKI_SERIAL1					USART1
#define RIKI_SERIAL1_IRQ				USART1_IRQn
#define RIKI_SERIAL1_CLK             	RCC_APB2Periph_USART1
#define RIKI_SERIAL1_GPIO_CLK           RCC_APB2Periph_GPIOA
#define RIKI_SERIAL1_GPIO_PORT          GPIOA
#define RIKI_SERIAL1_TX_PIN            	GPIO_Pin_9
#define RIKI_SERIAL1_RX_PIN             GPIO_Pin_10
#define RIKI_SERIAL1_NVIC				1

#define RIKI_SERIAL2                    USART3
#define RIKI_SERIAL2_IRQ                USART3_IRQn
#define RIKI_SERIAL2_CLK             	RCC_APB1Periph_USART3
#define RIKI_SERIAL2_GPIO_CLK        	RCC_APB2Periph_GPIOB
#define RIKI_SERIAL2_GPIO_PORT      	GPIOB
#define RIKI_SERIAL2_TX_PIN            	GPIO_Pin_10
#define RIKI_SERIAL2_RX_PIN             GPIO_Pin_11
#define RIKI_SERIAL2_NVIC				2

#define RXBUF_SIZE        				1024

/** Motor Config **/ 
typedef enum {
	MOTOR1 = 0,     //��ǰ���
	MOTOR2 = 1,     //��ǰ���
	MOTOR3 = 2,     //�����
	MOTOR4 = 3,     //�Һ���
	MOTOR_END = 4   
}Motor_TypeDef; 

#define MOTORn						4
#define RIKI_MOTOR1_A_PIN		 	GPIO_Pin_15             //DIN1  PB15
#define RIKI_MOTOR1_B_PIN   	 	GPIO_Pin_14             //DIN2  PB14 
#define RIKI_MOTOR1_GPIO_PORT	 	GPIOB                   
#define RIKI_MOTOR1_GPIO_CLK	 	RCC_APB2Periph_GPIOB    
#define RIKI_MOTOR1_PWM_PIN			GPIO_Pin_1              //PWMD   PB1-TIM3_CH4
#define RIKI_MOTOR1_PWM_PORT		GPIOB                   
#define RIKI_MOTOR1_PWM_CLK			RCC_APB2Periph_GPIOB    
#define RIKI_MOTOR1_PWM_TIM			TIM3                    
#define RIKI_MOTOR1_PWM_TIM_CLK 	RCC_APB1Periph_TIM3     

#define RIKI_MOTOR2_A_PIN		 	GPIO_Pin_6              //CIN1  PC6
#define RIKI_MOTOR2_B_PIN   	 	GPIO_Pin_7              //CIN2  PC7
#define RIKI_MOTOR2_GPIO_PORT	 	GPIOC               
#define RIKI_MOTOR2_GPIO_CLK	 	RCC_APB2Periph_GPIOC
#define RIKI_MOTOR2_PWM_PIN			GPIO_Pin_0              //PWMC PB0-TIM3_CH3
#define RIKI_MOTOR2_PWM_PORT	 	GPIOB
#define RIKI_MOTOR2_PWM_CLK			RCC_APB2Periph_GPIOB
#define RIKI_MOTOR2_PWM_TIM			TIM3
#define RIKI_MOTOR2_PWM_TIM_CLK 	RCC_APB1Periph_TIM3

#define RIKI_MOTOR3_A_PIN		 	GPIO_Pin_5              //AIN1  PA5
#define RIKI_MOTOR3_B_PIN   	 	GPIO_Pin_4              //AIN2  PA4
#define RIKI_MOTOR3_GPIO_PORT	 	GPIOA                   
#define RIKI_MOTOR3_GPIO_CLK	 	RCC_APB2Periph_GPIOA    
#define RIKI_MOTOR3_PWM_PIN			GPIO_Pin_6              //PWMA  PA6-TIM3_CH1
#define RIKI_MOTOR3_PWM_PORT		GPIOA                   
#define RIKI_MOTOR3_PWM_CLK			RCC_APB2Periph_GPIOA    
#define RIKI_MOTOR3_PWM_TIM			TIM3                    
#define RIKI_MOTOR3_PWM_TIM_CLK 	RCC_APB1Periph_TIM3     

#define RIKI_MOTOR4_A_PIN		 	GPIO_Pin_4             //CIN1   PC4
#define RIKI_MOTOR4_B_PIN   	 	GPIO_Pin_5             //CIN2   PC5
#define RIKI_MOTOR4_GPIO_PORT	 	GPIOC                   
#define RIKI_MOTOR4_GPIO_CLK	 	RCC_APB2Periph_GPIOC        
#define RIKI_MOTOR4_PWM_PIN			GPIO_Pin_7             //PWMB PA7-TIM3_CH2
#define RIKI_MOTOR4_PWM_PORT	 	GPIOA                   
#define RIKI_MOTOR4_PWM_CLK			RCC_APB2Periph_GPIOA    
#define RIKI_MOTOR4_PWM_TIM			TIM3                    
#define RIKI_MOTOR4_PWM_TIM_CLK 	RCC_APB1Periph_TIM3     

/** Encoder config **/
typedef enum {
	ENCODER1 = 0,   //��ǰ���������
	ENCODER2 = 1,   //��ǰ���������
	ENCODER3 = 2,   //�����������
	ENCODER4 = 3,   //�Һ���������
	ENCODER_END = 4
}Encoder_TypeDef; 

#define ENCODERn 					4

#define RIKI_ENCODER1_A_PIN         GPIO_Pin_11              //MA4-PA11
#define RIKI_ENCODER1_B_PIN         GPIO_Pin_12              //MB4-PA12
#define RIKI_ENCODER1_GPIO_PORT     GPIOA
#define RIKI_ENCODER1_GPIO_CLK      RCC_APB2Periph_GPIOA
#define RIKI_ENCODER1_A_EXTI_LINE   EXTI_Line11
#define RIKI_ENCODER1_B_EXTI_LINE   EXTI_Line12
#define RIKI_ENCODER1_A_IRQ         EXTI15_10_IRQn
#define RIKI_ENCODER1_B_IRQ         EXTI15_10_IRQn
#define RIKI_ENCODER1_A_EXTI_PORT   GPIO_PortSourceGPIOA
#define RIKI_ENCODER1_B_EXTI_PORT   GPIO_PortSourceGPIOA
#define RIKI_ENCODER1_A_EXTI_PIN    GPIO_PinSource11
#define RIKI_ENCODER1_B_EXTI_PIN    GPIO_PinSource12

#define RIKI_ENCODER2_A_PIN         GPIO_Pin_8              //MA3-PC8
#define RIKI_ENCODER2_B_PIN         GPIO_Pin_9              //MA3-PC9
#define RIKI_ENCODER2_GPIO_PORT     GPIOC
#define RIKI_ENCODER2_GPIO_CLK      RCC_APB2Periph_GPIOC
#define RIKI_ENCODER2_A_EXTI_LINE   EXTI_Line8
#define RIKI_ENCODER2_B_EXTI_LINE   EXTI_Line9
#define RIKI_ENCODER2_A_IRQ         EXTI9_5_IRQn
#define RIKI_ENCODER2_B_IRQ         EXTI9_5_IRQn
#define RIKI_ENCODER2_A_EXTI_PORT   GPIO_PortSourceGPIOC
#define RIKI_ENCODER2_B_EXTI_PORT   GPIO_PortSourceGPIOC
#define RIKI_ENCODER2_A_EXTI_PIN    GPIO_PinSource8
#define RIKI_ENCODER2_B_EXTI_PIN    GPIO_PinSource9

#define RIKI_ENCODER3_A_PIN         GPIO_Pin_6             //MA1-PB6
#define RIKI_ENCODER3_B_PIN         GPIO_Pin_7             //MB1-PB7
#define RIKI_ENCODER3_GPIO_PORT     GPIOB
#define RIKI_ENCODER3_GPIO_CLK      RCC_APB2Periph_GPIOB
#define RIKI_ENCODER3_A_EXTI_LINE   EXTI_Line6
#define RIKI_ENCODER3_B_EXTI_LINE   EXTI_Line7
#define RIKI_ENCODER3_A_IRQ         EXTI9_5_IRQn
#define RIKI_ENCODER3_B_IRQ         EXTI9_5_IRQn
#define RIKI_ENCODER3_A_EXTI_PORT   GPIO_PortSourceGPIOB
#define RIKI_ENCODER3_B_EXTI_PORT   GPIO_PortSourceGPIOB
#define RIKI_ENCODER3_A_EXTI_PIN    GPIO_PinSource6
#define RIKI_ENCODER3_B_EXTI_PIN    GPIO_PinSource7

#define RIKI_ENCODER4_A_PIN         GPIO_Pin_0             //MA2-PA0
#define RIKI_ENCODER4_B_PIN         GPIO_Pin_1             //MB2-PA1
#define RIKI_ENCODER4_GPIO_PORT     GPIOA
#define RIKI_ENCODER4_GPIO_CLK      RCC_APB2Periph_GPIOA
#define RIKI_ENCODER4_A_EXTI_LINE   EXTI_Line0
#define RIKI_ENCODER4_B_EXTI_LINE   EXTI_Line1
#define RIKI_ENCODER4_A_IRQ         EXTI0_IRQn
#define RIKI_ENCODER4_B_IRQ         EXTI1_IRQn
#define RIKI_ENCODER4_A_EXTI_PORT   GPIO_PortSourceGPIOA
#define RIKI_ENCODER4_B_EXTI_PORT   GPIO_PortSourceGPIOA
#define RIKI_ENCODER4_A_EXTI_PIN    GPIO_PinSource0
#define RIKI_ENCODER4_B_EXTI_PIN    GPIO_PinSource1

/* IMU TYPE CHOOSE */
#define USE_MPU6050_IMU
//#define USE_GY85_IMU

/** I2C Config**/
/* MPU6050 */
#define RIKI_SDA_PIN              GPIO_Pin_9
#define RIKI_SCL_PIN              GPIO_Pin_8
#define RIKI_I2C_GPIO_PORT        GPIOB
#define RIKI_I2C_GPIO_CLK         RCC_APB2Periph_GPIOB
#define SDA_IN()  {GPIOB->CRH&=0XFFFFFF0F;GPIOB->CRH|=8<<(1*4);}   //PB9����ģʽ
#define SDA_OUT() {GPIOB->CRH&=0XFFFFFF0F;GPIOB->CRH|=3<<(1*4);}   //PB9���ģʽ

/*GY-85*/
//#define RIKI_SDA_PIN          GPIO_Pin_2
//#define RIKI_SCL_PIN          GPIO_Pin_1
//#define RIKI_I2C_GPIO_PORT    GPIOC
//#define RIKI_I2C_GPIO_CLK     RCC_APB2Periph_GPIOC
//#define SDA_IN()  {GPIOC->CRH&=~(3<<(2*2));GPIOC->CRH|=0<<(2*2);}	 
//#define SDA_OUT() {GPIOC->CRH&=~(3<<(2*2));GPIOC->CRH|=1<<(2*2);}  


/* DHT22 Config*/
#define RIKI_DHT22_IO_IN()      {GPIOA->CRH&=0X0FFFFFFF;GPIOA->CRH|=8<<28;} 
#define RIKI_DHT22_IO_OUT()     {GPIOA->CRH&=0X0FFFFFFF;GPIOA->CRH|=3<<28;}
#define	RIKI_DHT22_DQ_OUT       PAout(15)     
#define	RIKI_DHT22_DQ_IN        PAin(15)       
#define RIKI_DHT22_PIN          GPIO_Pin_15
#define RIKI_DHT22_GPIO_PORT    GPIOA
#define RIKI_DHT22_GPIO_CLK     RCC_APB2Periph_GPIOA

/** Servo Config **/
typedef enum {
	SERVO1 = 0,
	SERVO2 = 1,
	SERVO_END = 2
}Servo_TypeDef; 

#define SERVOn 					2
#define MAX_ANGLE				180

#define RIKI_SERVO1_PIN				GPIO_Pin_2              //PA2-TIM2_CH3
#define RIKI_SERVO1_GPIO_PORT		GPIOA
#define RIKI_SERVO1_GPIO_CLK		RCC_APB2Periph_GPIOA
#define RIKI_SERVO1_TIM				TIM2
#define RIKI_SERVO1_TIM_CLK			RCC_APB1Periph_TIM2

#define RIKI_SERVO2_PIN				GPIO_Pin_3              //PA3-TIM2_CH4
#define RIKI_SERVO2_GPIO_PORT		GPIOA                   
#define RIKI_SERVO2_GPIO_CLK		RCC_APB2Periph_GPIOA    
#define RIKI_SERVO2_TIM				TIM2
#define RIKI_SERVO2_TIM_CLK			RCC_APB1Periph_TIM2

/** LED config **/
#define RIKI_LED_PIN                GPIO_Pin_3
#define RIKI_LED_GPIO_PORT			GPIOC
#define RIKI_LED_GPIO_CLK			RCC_APB2Periph_GPIOC

/** volt adc config **/
#define ADC1_DR_ADDRESS             ((u32)0x4001244C)
#define RIKI_BATTERY_PIN            GPIO_Pin_0
#define RIKI_BATTERY_GPIO_PORT      GPIOC
#define RIKI_BATTERY_GPIO_CLK       RCC_APB2Periph_GPIOC
#define RIKI_BATTERY_ADC_CLK        RCC_APB2Periph_ADC1
#define RIKI_BATTERY_DMA_CLK        RCC_AHBPeriph_DMA1

/** Sonar config **/
#define RIKI_ECHO_PIN               GPIO_Pin_8  //TIM1_CH1
#define RIKI_TRIG_PIN               GPIO_Pin_12
#define RIKI_ECHO_GPIO_PORT         GPIOA
#define RIKI_ECHO_GPIO_CLK          RCC_APB2Periph_GPIOA
#define RIKI_TRIG_GPIO_PORT         GPIOB
#define RIKI_TRIG_GPIO_CLK          RCC_APB2Periph_GPIOB
#define RIKI_SONAR_TIM              TIM1
#define RIKI_SONAR_TIM_CLK          RCC_APB2Periph_TIM1
#define RIKI_SONAR_TIM_IRQ          TIM1_CC_IRQn

/** GPIO Bit Config **/
#define BITBAND(addr, bitnum)   ((addr & 0xF0000000)+0x2000000+((addr &0xFFFFF)<<5)+(bitnum<<2)) 
#define MEM_ADDR(addr)  *((volatile unsigned long  *)(addr)) 
#define BIT_ADDR(addr, bitnum)  MEM_ADDR(BITBAND(addr, bitnum)) 
 
#define GPIOA_ODR_Addr    (GPIOA_BASE+12)  
#define GPIOB_ODR_Addr    (GPIOB_BASE+12)  
#define GPIOC_ODR_Addr    (GPIOC_BASE+12)  
#define GPIOD_ODR_Addr    (GPIOD_BASE+12)   
#define GPIOE_ODR_Addr    (GPIOE_BASE+12)  
#define GPIOF_ODR_Addr    (GPIOF_BASE+12)     
#define GPIOG_ODR_Addr    (GPIOG_BASE+12)  

#define GPIOA_IDR_Addr    (GPIOA_BASE+8)  
#define GPIOB_IDR_Addr    (GPIOB_BASE+8)  
#define GPIOC_IDR_Addr    (GPIOC_BASE+8)   
#define GPIOD_IDR_Addr    (GPIOD_BASE+8)  
#define GPIOE_IDR_Addr    (GPIOE_BASE+8)   
#define GPIOF_IDR_Addr    (GPIOF_BASE+8)  
#define GPIOG_IDR_Addr    (GPIOG_BASE+8)   

#define PAout(n)   BIT_ADDR(GPIOA_ODR_Addr,n)   
#define PAin(n)    BIT_ADDR(GPIOA_IDR_Addr,n) 

#define PBout(n)   BIT_ADDR(GPIOB_ODR_Addr,n)   
#define PBin(n)    BIT_ADDR(GPIOB_IDR_Addr,n) 

#define PCout(n)   BIT_ADDR(GPIOC_ODR_Addr,n)   
#define PCin(n)    BIT_ADDR(GPIOC_IDR_Addr,n)   

#define PDout(n)   BIT_ADDR(GPIOD_ODR_Addr,n)  
#define PDin(n)    BIT_ADDR(GPIOD_IDR_Addr,n)   

#define PEout(n)   BIT_ADDR(GPIOE_ODR_Addr,n)  
#define PEin(n)    BIT_ADDR(GPIOE_IDR_Addr,n)   

#define PFout(n)   BIT_ADDR(GPIOF_ODR_Addr,n)  
#define PFin(n)    BIT_ADDR(GPIOF_IDR_Addr,n) 

#endif // _CONFIG_H_

